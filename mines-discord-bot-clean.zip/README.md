# 💣 Minesweeper Discord Bot

This is a simple Discord bot built with `discord.js` that plays a 5x5 Minesweeper game based on how many mines the user wants.

## 🚀 How to Use

1. Clone this repo or upload to Replit
2. Create a `.env` file or use Replit Secrets:
   ```
   TOKEN=your-bot-token-here
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Start the bot:
   ```
   npm start
   ```

Then in Discord, type:

```
!mines 10
```

…and it will generate a Minesweeper board with 10 mines!
