const { Client, GatewayIntentBits } = require('discord.js');
require('dotenv').config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const BOARD_SIZE = 5;

client.once('ready', () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
  if (!message.content.startsWith('!mines') || message.author.bot) return;

  const args = message.content.split(' ');
  const mineCount = parseInt(args[1]);

  if (isNaN(mineCount) || mineCount < 1 || mineCount >= BOARD_SIZE * BOARD_SIZE) {
    return message.reply(`⚠️ Invalid number of mines. Choose between 1 and ${BOARD_SIZE * BOARD_SIZE - 1}`);
  }

  const board = generateBoard(BOARD_SIZE, mineCount);
  const display = renderBoard(board);

  message.channel.send(`💣 Minesweeper (${mineCount} mines):
\`\`\`
${display}
\`\`\``);
});

function generateBoard(size, mineCount) {
  const board = Array(size).fill(null).map(() => Array(size).fill(0));
  let placed = 0;

  while (placed < mineCount) {
    const row = Math.floor(Math.random() * size);
    const col = Math.floor(Math.random() * size);
    if (board[row][col] === '💣') continue;
    board[row][col] = '💣';
    placed++;
  }

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (board[r][c] === '💣') continue;
      let count = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < size && nc >= 0 && nc < size && board[nr][nc] === '💣') {
            count++;
          }
        }
      }
      board[r][c] = count === 0 ? '⬜' : `${count}`;
    }
  }

  return board;
}

function renderBoard(board) {
  return board.map(row => row.join(' ')).join('\n');
}

client.login(process.env.TOKEN);
